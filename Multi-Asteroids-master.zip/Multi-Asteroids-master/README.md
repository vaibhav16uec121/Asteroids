# Multi-Asteroids
Multi player asteroids over a local network

This project is a twist over the classic Asteriods game with multiplayear feature. It uses Node.js for the server and the socket-io
library for the communication between the clients and the servers. On the Client-side, it utilizes HTML5 Canvas for drawing the
objects.
